%%FIGURE REPORT
close all
u=1;
ns=nfout(u,1); % the number of bins is called
np=npsd(u,1); % the number of bins minus one (for (logarithmic) differential properties) is called
%scattering data
figure(1) 
XQplot=Q(u,1:ns); % scattering vectors (manipulated) are called
YIplot=I(u,1:ns); % scattering intensities (manipulated) are called
SNU1=char(SN(u)); % sample name is called
YIFplot=IFIT(u,1:ns); % scattering intensities (PDSP model) are called
XRplot=2.5./R(u,1:ns); % scattering vectors (PDSP model) are called based on the Radlinski approximation (2002)
loglog(XQplot,YIplot,'o','Linewidth',1,'DisplayName',['Measured ' SNU1])
hold on
loglog(XQplot,YIFplot,'.-','Linewidth',1,'DisplayName',['PDSP ' SNU1]) % the x-axis is Q and the y-axis is I(Q)
xlabel('Q, Å^-^1','FontSize',11,'FontWeight','bold') % Q is expressed in Å^-^1
ylabel('I(Q), cm^-^1','FontSize',11,'FontWeight','bold') % I(Q) is expressed in cm^-^1
title('Fitted PDSP Model')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%probability function of the pore (scatterer) size distribution
figure(2)
XFrplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2 
YFrplot=10.*Fr(u,1:ns); % f(r) is converted from angstrom (Å^-^1) to nanometer (nm^-^1)
SNU2=char(SN(u));
loglog(XFrplot,YFrplot,'d-','Linewidth',1,'DisplayName',SNU2) % the x-axis is scatterer size or pore diamater and the y-axis is f(r) 
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('f(r), nm^-^1','FontSize',11,'FontWeight','bold') % f(r) is expressed in nm^-^1
title('Probability Function of the Pore Size Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%Slope Distribution
figure(3)
XSplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
YSplot=S(u,1:ns); % slope of each bin is called
SNU3=char(SN(u));
loglog(XSplot,YSplot,'d-','Linewidth',1,'DisplayName', SNU3) % the x-axis is scatterer size or pore diamater and the y-axis is slope
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Slope','FontSize',11,'FontWeight','bold') % slope is dimensionless
title('Slope Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%Fractal Dimension Distribution
figure(4)
XFplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
YFplot=fD(u,1:ns); % frctal dimension of each bin is called
SNU4=char(SN(u));
loglog(XFplot,YFplot,'d-','Linewidth',1,'DisplayName', SNU4) % the x-axis is scatterer size or pore diamater and the y-axis is fractal dimension
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('fD','FontSize',11,'FontWeight','bold') % fractal dimension is dimensionless
title('Fractal Dimension Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%incremental specific surface area (SSA) distribution or SSA of scatterers
figure(5)
Xssaplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yssaplot=SSA(u,1:ns); % incremental SSA is called
SNU5=char(SN(u));
semilogx(Xssaplot,Yssaplot,'d-','Linewidth',1,'DisplayName',SNU5) % the x-axis is scatterer size or pore diamater and the y-axis is incremental SSA
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Pore Area, m^2/g','FontSize',11,'FontWeight','bold') % SSA is expressed in m2/g
title('Incremental Pore Area Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%cumulative specific surface area distribution or SSA of scatterers
figure(6)
Xssacumplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yssacumplot=SSAcum(u,1:ns); % cumulative SSA is called
SNU6=char(SN(u));
semilogx(Xssacumplot,Yssacumplot,'d-','Linewidth',1,'DisplayName',SNU6) % the x-axis is scatterer size or pore diamater and the y-axis is cumulative SSA
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Pore Area, m^2/g','FontSize',11,'FontWeight','bold') % SSA is expressed in m2/g
title('Cumulative Pore Area Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%differential pore (scatterer) area distribution
figure(7)
Xdsdrplot=0.2.*R(u,1:np); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Ydsdrplot=5.*dsdr(u,1:np); % differential pore area (dS/dr) is converted from radius [m2/g/Å] to diameter [m2/g/nm]. the conversion factor is 5
SNU7=char(SN(u));
semilogx(Xdsdrplot,Ydsdrplot,'d-','Linewidth',1,'DisplayName',SNU7) % the x-axis is scatterer size or pore diamater and the y-axis is differential pore area
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('dA/dD Pore Area, m^2/g/nm','FontSize',11,'FontWeight','bold') % differential pore area is expressed in m2/g/nm
title('Differential Pore Area Distribution','FontSize',11,'FontWeight','bold')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%logarithmic differential pore (scatterer) area distribution
figure(8)
Xdsdlogrplot=0.2.*R(u,1:np); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Ydsdlogrplot=dsdlogr(u,1:np); % logarithmic differential pore area is called
SNU8=char(SN(u));
loglog(Xdsdlogrplot,Ydsdlogrplot,'d-','Linewidth',1,'DisplayName',SNU8) % the x-axis is scatterer size or pore diamater and the y-axis is logarithmic differential pore area
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('dA/dlogD Pore Area, m^2/g','FontSize',11,'FontWeight','bold') % logarithmic differential pore area is expressed in m2/g
title('Logarithmic Differential Pore Area Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%incremental porosity distribution or volume fraction of scatterers
figure(9)
Xphiplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yphiplot=phi(u,1:ns); % incremental porosity is called
SNU9=char(SN(u));
semilogx(Xphiplot,Yphiplot,'d-','Linewidth',1,'DisplayName',SNU9) % the x-axis is scatterer size or pore diamater and the y-axis is incremental porosity
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Incremental Porosity, %','FontSize',11,'FontWeight','bold') % incremental porosity is expressed in %
title('Incremental Porosity Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%cumulative porosity distribution or volume fraction of scatterers
figure(10)
Xphicumplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yphicumplot=phicum(u,1:ns); % cumulative porosity is called
SNU10=char(SN(u));
plot(Xphicumplot,Yphicumplot,'d-','Linewidth',1,'DisplayName',SNU10) % the x-axis is scatterer size or pore diamater and the y-axis is cumulative porosity
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Cumuulative Porosity, %','FontSize',11,'FontWeight','bold') % cumulative porosity is expressed in %
title('Cumulative Porosity Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%incremental pore (scatterer) volume distribution or volume of scatterers
figure(11)
Xvpplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yvpplot=Vp(u,1:ns); % incremental pore volume is called
SNU11=char(SN(u));
semilogx(Xvpplot,Yvpplot,'d-','Linewidth',1,'DisplayName',SNU11) % the x-axis is scatterer size or pore diamater and the y-axis is incremental pore volume
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Pore Volume, cm^3/g','FontSize',11,'FontWeight','bold') % incremental pore volume is expressed in cm3/g
title('Incremental Pore Volume Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%cumulative pore (scatterer) volume distribution or volume of scatterers
figure(12)
Xvpcumplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yvpcumplot=Vcum(u,1:ns); % cumulative pore volume is called
SNU12=char(SN(u));
semilogx(Xvpcumplot,Yvpcumplot,'d-','Linewidth',1,'DisplayName',SNU12) % the x-axis is scatterer size or pore diamater and the y-axis is cumulative pore volume
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('Pore Volume, cm^3/g','FontSize',11,'FontWeight','bold') % cumulative pore volume is expressed in cm3/g
title('Cumulative Pore Volume Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%differential pore (scatterer) volume distribution
figure(13)
Xdvdrplot=0.2.*R(u,1:np); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Ydvdrplot=5.*dvdr(u,1:np); % differential pore volume (dV/dr) is converted from radius [cm3/g/Å] to diameter [cm3/g/nm]. the conversion factor is 5
SNU13=char(SN(u));
semilogx(Xdvdrplot,Ydvdrplot,'d-','Linewidth',1,'DisplayName',SNU13) % the x-axis is scatterer size or pore diamater and the y-axis is differential pore volume
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('dV/dD Pore Volume, cm^3/g/nm','FontSize',11,'FontWeight','bold') % differential pore volume is expressed in cm3/g/nm
title('Differential Pore Volume Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%logarithmic differential pore (scatterer) volume distribution
figure(14)
Xdvdlogrplot=0.2.*R(u,1:np); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Ydvdlogrplot=dvdlogr(u,1:np); % logarithmic differential pore volume is called
SNU14=char(SN(u));
loglog(Xdvdlogrplot,Ydvdlogrplot,'d-','Linewidth',1,'DisplayName',SNU14) % the x-axis is scatterer size or pore diamater and the y-axis is logarithmic differential pore volume
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('dV/dlogD Pore Volume, cm^3/g','FontSize',11,'FontWeight','bold') % logarithmic differential pore volume is expressed in cm3/g
title('Logarithmic Differential Pore Volume Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%volume-weighed pore (scatterer) size distribution
figure(15)
Xd3frplot=0.2.*R(u,1:ns); % scatterer (pore) size is converted from radius [Å] to diameter [nm]. the conversion factor is 0.2
Yd3frplot=D3FR(u,1:ns); % volume-weighed pore size (D3 x f(r)) is called
SNU15=char(SN(u));
semilogx(Xd3frplot,Yd3frplot,'d-','Linewidth',1,'DisplayName',SNU15) % the x-axis is scatterer size or pore diamater and the y-axis is volume-weighed pore size 
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold') % scatterer size or pore diamater is expressed in nm
ylabel('D^3f(r), nm^2','FontSize',11,'FontWeight','bold') % volume-weighed pore size is expressed in nm2
title('Volume-weighed Pore Size Distribution')
hold on
legend('show')
legend('Location','best')
legend('boxoff')
%error analysis
figure(16)
XdSSQdIQoplot=LOGDiam(u,1:np); % logarithmic form of pore (scatterer) size is called
YdSSQdIQoplot=dSSQdlogIQo(u,1:np); % dSSQ/dlogIQ0 is called
SNU16=char(SN(u));
plot(XdSSQdIQoplot,YdSSQdIQoplot,'d-','Linewidth',1,'DisplayName',SNU16) % the x-axis is log(D) and the y-axis is dSSQ/dlog(IQ0)
ylim([-5 5]) % y-axis is limited between -5 and +5
xlabel('log(D)','FontSize',11,'FontWeight','bold') % log(D) is dimensionless
ylabel('dSSQ/dlog(IQ0)','FontSize',11,'FontWeight','bold') % dSSQ/dlog(IQ0) is dimensionless
title('Error Analysis')
hold on
legend('show')
legend('Location','best')
legend('boxoff')

path=[pwd];   % current path is given
newfolder='Results';   % the new folder "Results" is generated 
folder=mkdir([path,filesep,newfolder]);
path=[path,filesep,newfolder];
for k=1:16 % 16 figures are called
    figure(k); % each figure is called
    temp1=[path,filesep,'fig',num2str(k),'.emf']; % "fig" is figure name and ".emf" is the format of figures
    saveas(gca,temp1);
    temp2=[path,filesep,'fig',num2str(k),'.tif']; % "fig" is figure name and ".tif" is the format of figures
    saveas(gca,temp2);
end
fprintf('\n')
fprintf('The figures have been saved in the Results folder.\n')
%%Excel Output
folderpath=pwd; % current path is given
folderpath=[folderpath,filesep,newfolder];
baseFileName='output.csv'; % results are generated in a CSV file under output.csv
filename = fullfile(folderpath, baseFileName);
n=NFINAL(u,1); % the number of scattering vectors (measured) is called
nf=Nfinl(u,1); % the number of scattering vectors (manipulated) is called
ns=nfout(u,1); % the number of bins is called
np=npsd(u,1); % the number of bins minus one (for (logarithmic) differential properties) is called
SNF=char(SN(u)); % sample name is called
SSQA=SSQabs(u,1); % summation of squared errors is called
ITERATION=Iteration(u,1); % the number of iterations is called
SLop=Slope(3,u); % slopes are called
SLOP_UPPER=slopupper(u,1); % upper limit of slopes is called
SLOP_LOWER=sloplower(u,1); % lower limit of slopes is called
FD=FractalDim(3,u); % fractal dimensions are called
FD_UPPER=fdupper(u,1); % upper limit of fractal dimensions is called
FD_LOWER=fdlower(u,1); % lower limit of fractal dimensions is called
SFD=FractalDim(2,u); % surface fractal dimensions are called
SFD_UPPER=sfdupper(u,1); % upper limit of surface fractal dimensions is called
SFD_LOWER=sfdlower(u,1); % lower limit of surface fractal dimensions is called
PFD=FractalDim(1,u); % pore/mass fractal dimensions are called
PFD_UPPER=pfdupper(u,1); % upper limit of pore fractal dimensions is called
PFD_LOWER=pfdlower(u,1); % lower limit of pore fractal dimensions is called
IBGVSAS=Ib(1,u); % VSAS background is called
VSASBKGR_UPPER=vsasbkgrupper(u,1); % upper limit of I-Q data to measure VSAS background is called
VSASBKGR_LOWER=vsasbkgrlower(u,1); % lower limit of I-Q data to measure VSAS background is called
IBGSAS=Ib(2,u); % SAS background is called
SASBKGR_UPPER=sasbkgrupper(u,1); % upper limit of I-Q data to measure SAS background is called
SASBKGR_LOWER=sasbkgrlower(u,1); % lower limit of I-Q data to measure SAS background is called
DMIN=0.2.*Ri(u,1); % minimum pore (scatterer) size of each bin is converted from radius [A] to diameter [nanometer, nm]. the conversion factor is 0.2
DMAX=0.0002.*Rf(u,1); % maximum pore (scatterer) size of each bin is converted from radius [A] to diameter [micrometer, um]. the conversion factor is 0.0002
SSAT=SSAt(u,1); % cumulative specific surface area (SSA) is called. it is also called pore (scatterer) area 
SSAMACRO=SSAmacro(u,1); % macro SSA is called
SSAMESO=SSAmeso(u,1); % meso SSA is called
SSAMESO5=SSAmeso5(u,1);SSAMESO10=SSAmeso10(u,1);SSAMESO25=SSAmeso25(u,1); % other range of SSAs are called
PVT=Vcumt(u,1); % cumulative pore (scatterer) volume is called
VMACRO=Vmacro(u,1); % macro pore volume is called
VMESO=Vmeso(u,1); % meso pore volume is called
VMESO5=Vmeso5(u,1);VMESO10=Vmeso10(u,1);VMESO25=Vmeso25(u,1); % other range of pore volumes are called
PHIT=PHIt(u,1); % cumulative porosity is called
PHIMACRO=PHImacro(u,1); % macro porosity is called
PHIMESO=PHImeso(u,1); % meso porosity is called
PHIMESO5=PHImeso5(u,1);PHIMESO10=PHImeso10(u,1);PHIMESO25=PHImeso25(u,1);  % other rage of porosities are called
%Header
sheet=u; % each sheet represents the individual sample
header={'Sample Name',SNF,'','SSQ',SSQA,'','Iteration',ITERATION,'','','','','','','','','','','','','','','','','','';...
    'Slope',SLop,'','Slop Q-Range','Upper',SLOP_UPPER,'Lower',SLOP_LOWER,'','','','','','','','','','','','','','','','','','';...
    'Fractal Dimension',FD,'','Fractal Dimension Q-Range','Upper',FD_UPPER,'Lower',FD_LOWER,'','','','','','','','','','','','','','','','','','';...
    'Surface Fractal Dimension',SFD,'','Surface Fractal Dimension Q-Range','Upper',SFD_UPPER,'Lower',SFD_LOWER,'','','','','','','','','','','','','','','','','','';...
    'Pore Fractal Dimension',PFD,'','Pore Fractal Dimension Q-Range','Upper',PFD_UPPER,'Lower',PFD_LOWER,'','','','','','','','','','','','','','','','','','';...
    'VSAS Background, cm^-1',IBGVSAS,'','VSAS Background Range','Upper',VSASBKGR_UPPER,'Lower',VSASBKGR_LOWER,'','','','','','','','','','','','','','','','','','';...
    'SAS Background, cm^-1',IBGSAS,'','SAS Background Range','Upper',SASBKGR_UPPER,'Lower',SASBKGR_LOWER,'','','','','','','','','','','','','','','','','','';...
    'Dmin, nm',DMIN,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Dmax, um',DMAX,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Total Pore Area, m^2/g',SSAT,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Macropore Area, m^2/g',SSAMACRO,'','@ 5nm','@ 10nm','@ 25nm','@ 50nm','','','','','','','','','','','','','','','','','','','';...
    'Mesopore Area, m^2/g',SSAMESO,'',SSAMESO5,SSAMESO10,SSAMESO25,SSAMESO,'','','','','','','','','','','','','','','','','','','';...
    'Total Pore Volume, cm^3/g',PVT,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Macropore Volume, cm^3/g',VMACRO,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Mesopore Volume, cm^3/g',VMESO,'',VMESO5,VMESO10,VMESO25,VMESO,'','','','','','','','','','','','','','','','','','','';...
    'Total Porosity, %',PHIT,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Macroporosity, %',PHIMACRO,'','','','','','','','','','','','','','','','','','','','','','','','';...
    'Mesoporosity, %',PHIMESO,'',PHIMESO5,PHIMESO10,PHIMESO25,PHIMESO,'','','','','','','','','','','','','','','','','','','';...
    '','','','','','','','','','','','','','','','','','','','','','','','','','';...
    'Qmeasured, A^-1','Imeasured(Q), cm^-1','Qmanipulated, A^-1','Imanipulated(Q), cm^-1','Qmanipulated_binlength, A^-1','Imanipulated_binlength(Q), cm^-1','Ifitted(Q), cm^-1','Dmin, nm','Dmax, nm','Pore Size (D), nm','f(r), nm^-1','Slope','fD','Incremental Pore Area, m^2/g','Cumulative Pore Area, m^2/g','dA/dD Pore Area, m^2/g/nm','dA/dlogD Pore Area, m^2/g','Incremental Porosity, %','Cummulative Porosity, %','Incremental Pore Volume, cm^3/g','Cummulative Pore Volume, cm^3/g','dV/dD Pore Volume, cm^3/g/nm','dV/dlogD Pore Volume, cm^3/g','D^3f(r), nm^2','log(D)','dSSQ/dlog(IQ0)'}; % header is written
xlswrite(filename,header,sheet) % header is generated in output file
%Measured Scattering Vector
range1='A21'; 
Qmsout=QMEAS(u,1:n); 
data1=Qmsout'; 
xlswrite(filename,data1,sheet,range1) % Q measured is generated in output file
%Measured Scattering Intensity
range2='B21';
Imsout=IMEAS(u,1:n); 
data2=Imsout';
xlswrite(filename,data2,sheet,range2) % I(Q) measured is generated in output file
%Manipulated Scattering Vector
range3='C21'; 
Qtrout=Qtr(u,1:nf); 
data3=Qtrout'; 
xlswrite(filename,data3,sheet,range3) % Q manipulated is generated in output file
%Manipulated Scattering Intensity
range4='D21';
Itrout=Itr(u,1:nf); 
data4=Itrout';
xlswrite(filename,data4,sheet,range4) % I(Q) manipulated is generated in output file
%Manipulated Scattering Vector (bin length)
range5='E21';
Qout=Q(u,1:ns);
data5=Qout';
xlswrite(filename,data5,sheet,range5) % Q manipulated is generated in output file
%Manipulated Scattering Intensity (bin length)
range6='F21';
Ieout=I(u,1:ns);
data6=Ieout';
xlswrite(filename,data6,sheet,range6) % I(Q) manipulated is generated in output file
%Fitted Scattering Intensity
range7='G21';
Iout=IFIT(u,1:ns); 
data7=Iout';
xlswrite(filename,data7,sheet,range7) % I(Q) fitted is generated in output file
%Minimum Pore (Scatterer) Size
range8='H21';
Dminout=0.2.*Rmin(u,1:ns); % minimum pore (scatterer) size of each bin is converted from radius [A] to diameter [nm]. the conversion factor is 0.2
data8=Dminout';
xlswrite(filename,data8,sheet,range8) % minimum pore (scatterer) size is generated in output file
%Maximum Pore (Scatterer) Size
range9='I21';
Dmaxout=0.2.*Rmax(u,1:ns); % maximum pore (scatterer) size of each bin is converted from radius [A] to diameter [nm]. the conversion factor is 0.2
data9=Dmaxout';
xlswrite(filename,data9,sheet,range9) % maximum pore (scatterer) size is generated in output file
%Pore (Scatterer) Size
range10='J21';
Dout=0.2.*R(u,1:ns); % pore (scatterer) size of each bin is converted from radius [A] to diameter [nm]. the conversion factor is 0.2
data10=Dout';
xlswrite(filename,data10,sheet,range10) % pore (scatterer) size is generated in output file
%Probability Function of the Pore (Scatterer) Size Distribution
range11='K21';
frout=10.*Fr(u,1:ns); % f(r) is converted from angstrom (Å^-^1) to nanometer (nm^-^1). the conversion factor is 10
data11=frout';
xlswrite(filename,data11,sheet,range11) % f(r) is generated in output
%Slope Distribution
range12='L21';
Sout=S(u,1:ns); 
data12=Sout';
xlswrite(filename,data12,sheet,range12) % slope is generated in output file
%Fractal Distribution
range13='M21';
fDout=fD(u,1:ns); 
data13=fDout';
xlswrite(filename,data13,sheet,range13) % fractal dimension is generated in output file
%Incremental Pore (Scatterer) Area Distribution
range14='N21';
IPAout=SSA(u,1:ns); 
data14=IPAout';
xlswrite(filename,data14,sheet,range14) % incremental SSA is generated in output file
%Cumulative Pore Area Distribution
range15='O21';
CPAout=SSAcum(u,1:ns); 
data15=CPAout';
xlswrite(filename,data15,sheet,range15) % cumulative SSA is generated in output file
%Differential Pore (Scatterer) Area Distribution
range16='P21';
DPAout=5.*dsdr(u,1:np); % differential pore area (dS/dr) is converted from radius [m2/g/Å] to diameter [m2/g/nm]. the conversion factor is 5
data16=DPAout';
xlswrite(filename,data16,sheet,range16) % differential pore area is generated in output file
%Logarithmic Differential Pore (Scatterer) Area Distribution
range17='Q21';
LDPAout=dsdlogr(u,1:np); 
data17=LDPAout';
xlswrite(filename,data17,sheet,range17) % logarithmic differential pore area is generated in output file
%Incremental Porosity Distribution
range18='R21';
IPout=phi(u,1:ns); 
data18=IPout';
xlswrite(filename,data18,sheet,range18) % incremental porosity is generated in output file
%Cumulative Porosity Distribution
range19='S21';
CPout=phicum(u,1:ns); 
data19=CPout';
xlswrite(filename,data19,sheet,range19) % cumulative porosity is generated in output file
%Incremental Pore (Scatterer) Volume Distribution
range20='T21';
IPVout=Vp(u,1:ns); 
data20=IPVout';
xlswrite(filename,data20,sheet,range20) % incremental pore volume is generated in output file
%Cumulative Pore (Scatterer) Volume Distribution
range21='U21';
CPVout=Vcum(u,1:ns);
data21=CPVout';
xlswrite(filename,data21,sheet,range21) % cumulative pore volume is generated in output file
%Differential Pore (Scatterer) Volume Distribution
range22='V21';
DPVout=5.*dvdr(u,1:np); % differential pore volume (dV/dr) is converted from radius [cm3/g/Å] to diameter [cm3/g/nm]. the conversion factor is 5
data22=DPVout';
xlswrite(filename,data22,sheet,range22) % differential pore volume is generated in output file
%Logarithmic Differential Pore (Scatterer) Volume Distribution
range23='W21';
LDPVout=dvdlogr(u,1:np); 
data23=LDPVout';
xlswrite(filename,data23,sheet,range23) % logarithmic differential pore volume is generated in output file
%Volume-weighed Pore (Scatterer) Size Distribution
range24='X21';
D3FRout=D3FR(u,1:ns); 
data24=D3FRout';
xlswrite(filename,data24,sheet,range24) % volume-weighed pore size is generated in output file
%Error Analysis
range25='Y21';
logDiamout=LOGDiam(u,1:np); 
data25=logDiamout';
xlswrite(filename,data25,sheet,range25) % log(D) is generated in output file
range26='Z21';
dSSQdlogIQoout=dSSQdlogIQo(u,1:np); 
data26=dSSQdlogIQoout';
xlswrite(filename,data26,sheet,range26) % dSSQ/dlog(IQ0) is generated in output file
fprintf('\n')
fprintf('The spreadsheets containing results have been saved in the Results folder.\n')
fprintf('\n')
fprintf('***END***\n')
fprintf('\n')