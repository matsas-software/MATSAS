for u=1:NSheet
    %%call for data
    l=L(u)-8;
    
    Qv=QV(1:l,u).'; %VSAS Q-values are placed in a single row matrix
    Iv=IV(1:l,u).'; %VSAS I-values are placed in a single row matrix
    dIv=dIV(1:l,u).'; %VSAS dI-values are placed in a single row matrix
    
    %non-numeric elements of VSAS data are discarded
    findv=find(Qv(1:end)>0); 
    findv1=findv(1); 
    findv2=findv(end);
    Qv=Qv(findv1:findv2); %VSAS numeric Q-values are denoted
    Iv=Iv(findv1:findv2); %VSAS numeric I-values are denoted
    dIv=dIv(findv1:findv2); %VSAS numeric dI-values are denoted
    
    QVmeas=Qv; IVmeas=Iv; dIVmeas=dIv; % unprocessed VSAS data
    
    %%overlap area
    m=length(Qv);
    vi=1;
    vf=m;
    
    %%noise removal of VSAS data 
    fvolp=vf;
    offsetVSAS=50; % last 50 I-Q values of VSAS are processed for noise removal
    % Ensure the starting index is valid even for short datasets
    startIdxVSAS   = max(vi + offsetVSAS, 2);
    if startIdxVSAS > fvolp
        startIdx = max(fvolp - 1, vi);  % at least 2 points if possible
    end
    ivolp = startIdxVSAS;
    Qvfo=Qv(ivolp:fvolp); Ivfo=Iv(ivolp:fvolp); 
    FQ=Qvfo; FI=Ivfo; Fl=length(Qvfo); % inputs for the LSFpow function: slope and intercept of the data points selected outside the overlap area are found
    [A,B,~]=LSFpow(FQ,FI,Fl);
    Qvd=Qv(ivolp:fvolp); Ivd=Iv(ivolp:fvolp); dIvd=dIv(ivolp:fvolp); md=length(Qvd);
    Ivdfit=zeros(1,md); erv=zeros(1,md); Qvdfit=Qvd;
    for k=1:md
        Ivdfit(k)=A*((Qvdfit(k))^B); % the power law model is fitted to the data points selected inside the overlap area 
        erv(k)=log(Ivd(k))-log(Ivdfit(k)); % error is found for the individual data points
        erv(k)=abs(erv(k)); % absolute error is found for the individual data points
    end
    ervm=max(erv); % maximum of the absolute errors is found
    dvp=100; % the percentage of data points being less than maximum error that is remained
    cervm=0.01*dvp*ervm;
    Qvds=zeros(1,md); Ivds=zeros(1,md); dIvds=zeros(1,md);
    for k=1:md % noise removal operation
        if erv(k) < cervm
           Qvds(k)=Qvd(k);
           Ivds(k)=Ivd(k);
           dIvds(k)=dIvd(k);
        end
    end
    IC=1:1:md; QSR=[Qvds;Ivds;dIvds;IC]; QSR=QSR'; QSR=sortrows(QSR,[1,4]); QSR=QSR'; % data are sorted after noise removal
    Qvd=QSR(1,:); Ivd=QSR(2,:); dIvd=QSR(3,:);
    findvd=find(Qvd>0); mvd1=findvd(1); mvd2=findvd(end); 
    Qvd=Qvd(mvd1:mvd2); Ivd=Ivd(mvd1:mvd2); dIvd=dIvd(mvd1:mvd2);
    Qvr=[Qv(vi:ivolp-1) Qvd]; Ivr=[Iv(vi:ivolp-1) Ivd]; dIvr=[dIv(vi:ivolp-1) dIvd]; mr=length(Qvr); % VSAS data for further manipulation
    
    %%VSAS Background Subtraction
    Qvlp1=0.0003; %upper cut-off for VSAS background subtraction
    Qvlp2=0.003; %lower cut-off for VSAS background subtraction
    vsasbkgrupper(u,1)=Qvlp1; %upper cut-off for VSAS background subtraction to be addressed in output
    vsasbkgrlower(u,1)=Qvlp2; %lower cut-off for VSAS background subtraction to be addressed in output
    for i=1:mr % finding first data point after upper cut-off
        if Qvr(i) >= Qvlp1
           break 
        end
    end
    qvlp1=i; ivlp1=i; % first data point is found
    for i=1:mr % finding last data point before lower cut-off
        if Qvr(i) >= Qvlp2
            break
        end
    end
    qvlp2=i; ivlp2=i; % last data point is found
    FQ=Qvr(qvlp1:qvlp2);FI=Ivr(ivlp1:ivlp2);Fl=length(FQ);
    [~,B,~]=LSFpow(FQ,FI,Fl); % the LSFpow model is fitted to the data points selected
    B=(-B);
    FQ=Qvr.^B; FI=(Qvr.^B).*Ivr; 
    hbpv=30; % the percentage of first points to be removed for regression
    hbv=round(0.01*hbpv*mr);
    if hbv==0
        hbv=1;
    end
    FQ=FQ(hbv:mr); FI=FI(hbv:mr); FL=length(FQ); % final VSAS data points for background subtraction
    [a,b,~]=LSFlin(FQ,FI,FL); % the LSFlin model is used for background subtraction 
    Ibckvsas=b; % slope is the background
    Ivr=Ivr-Ibckvsas; % I values of VSAS are subtracted
    
    %%SAS Background Subtraction
    sasbkgrupper(u,1)=0; %upper cut-off for SAS background subtraction to be addressed in output
    sasbkgrlower(u,1)=0; %lower cut-off for SAS background subtraction to be addressed in output
    Ibcksas=0; % slope is the background
    
    %measured (un-manipulated) data report
    Qmeasured=QVmeas(vi:vf); % Q values of VSAS curve unmanipulated are combined
    Imeasured=IVmeas(vi:vf); % I values of VSAS curve unmanipulated are combined
    nmeas=length(Qmeasured);
    ICmeas=1:1:nmeas; QSR=[Qmeasured;Imeasured;ICmeas]; QSR=QSR'; QSR=sortrows(QSR,[1,3]); QSR=QSR'; % data are sorted
    Qmeasured=QSR(1,:); Imeasured=QSR(2,:);
    NFINAL(u,1)=nmeas;
    QMEAS(u,1:NFINAL(u,1))=Qmeasured(1:NFINAL(u,1)); % the Q values unmanipulated to be reported in output or here
    IMEAS(u,1:NFINAL(u,1))=Imeasured(1:NFINAL(u,1)); % the I values unmanipulated to be reported in output or here
    
    %%data reduction
    %smallest Q cut-off
    Qcom=Qvr(1:mr); Icom=Ivr(1:mr); dIcom=dIvr(1:mr);
    ncom=mr;
    if upsiz(1,u)> 0
       Qucoff=upsiz(1,u); % the smallest Q cut-off is called
    else
        Qucoff=Qcom(1); % otherwise, the smallest Q cut-off is the first Q value
    end
    for i=1:ncom % smallest Q cut-off finding operation
        if Qcom(i) > Qucoff && i==1
           upp=i;
           break
        elseif Qcom(i) == Qucoff
               upp=i;
               break
        elseif Qcom(i) > Qucoff
               FQ=[log10(Qcom(i-1)) log10(Qcom(i))]; 
               FI=[log10(Icom(i-1)) log10(Icom(i))]; 
               FL=2;
               [a,b,~]=LSFlin(FQ,FI,FL);
               Iucoff=10^(a+b*log10(Qucoff));
               Qcom(i-1)=Qucoff; Icom(i-1)=Iucoff;
               upp=i-1;
               break
        end
    end
    Qupd=Qcom(upp:ncom); Iupd=Icom(upp:ncom); dIupd=dIcom(upp:ncom); nupd=ncom-upp+1; % data before upper cut-off are discarded 
    
    %largest Q cut-off
    if lowsiz(1,u)> 0
       Qlcoff=lowsiz(1,u); % the largest Q cut-off is called
    else
        Qlcoff=Qcom(end); % otherwise, the largest Q cut-off is the last Q value
    end
    for i=1:nupd % largest Q cut-off finding operation
        if Qupd(i) < Qlcoff && i==nupd
           lower=nupd;
           break
        elseif Qupd(i) == Qlcoff
               lower=i;
               break
        elseif Qupd(i) > Qlcoff
               FQ=[log10(Qupd(i-1)) log10(Qupd(i))]; 
               FI=[log10(Iupd(i-1)) log10(Iupd(i))]; 
               FL=2;
               [a,b,~]=LSFlin(FQ,FI,FL);
               Ilcoff=10^(a+b*log10(Qlcoff));
               Qupd(i)=Qlcoff; Iupd(i)=Ilcoff;
               lower=i;
               break
        end
    end
    Qsmooth=Qupd(1:lower); Ismooth=Iupd(1:lower); dIsmooth=dIupd(1:lower); % data after lower cut-off are discarded and data are ready for smoothing
    
    %%curve smoothing: Part 1
    nsmt1=0; %degree of smoothing
    for i=1:nsmt1 %smooth operation for reducing more noises
        Ismooth=smooth(Qsmooth,Ismooth,0.04,'loess');
    end
    Ismooth=Ismooth';
    nfin=lower; 
    Qfin=Qsmooth; Ifin=Ismooth; dIfin=dIsmooth; % data after first round of smoothing
    Qfin1(u,1:nfin)=Qfin; Ifin1(u,1:nfin)=Ifin; dIfin1(u,1:nfin)=dIfin; 
    
    %%curve smoothing: Part 2
    deltaqfin=(Qfin(end)-Qfin(1))./3; % Q values are equally devided by 3
    qisolp=Qfin(1)+deltaqfin; % the begining of the mid Q values is found
    qfvolp=Qfin(1)+2*deltaqfin; % the end of the mid Q values is found
    qsmooth1=qisolp;
    qsmooth2=qfvolp;
    for i=1:nfin
        if Qfin(i) >= qsmooth1
           break 
        end
    end
    qnsmooth1=i; insmooth1=i; % I-Q value at the begining of overlap area
    for i=1:nfin
        if Qfin(i) >= qsmooth2
            break
        end
    end
    qnsmooth2=i; insmooth2=i; % I-Q value at the end of overlap area
    
    for i=1:nfin
        if Qfin(i) <= Qfin(qnsmooth1) % smoothing operation for the first third of data points
            k=1; 
            T=1; % the number of points before and after an individual data point from which the slope of the individual data point is calculated
            TT=2*T+1;
            for t=1:TT
                j=i-1+t-T;
                if j > nfin
                    j=nfin;
                    k=k-1;
                elseif j <= 1
                        j=1;
                        k=1;
                end
                Qsm(u,k)=Qfin1(u,j);
                Ism(u,k)=Ifin1(u,j);
                k=k+1;
            end
            FQ=Qsm(u,1:k-1);
            FI=Ism(u,1:k-1);
            Fl=length(FQ);
            [A,B,~]=LSFpow(FQ,FI,Fl);
            Ifin(i)=A*((Qfin(i))^B); % I values of this region are smoothed
        elseif Qfin(i) >= Qfin(qnsmooth2) % smoothing operation for the last third of data points  
                k=1;
                T=1; % the number of points before and after an individual data point from which the slope of the individual data point is calculated
                TT=2*T+1;
                for t=1:TT
                    j=i-1+t-T;
                    if j > nfin
                       j=nfin;
                       k=k-1;
                    elseif j <= 1
                           j=1;
                           k=1;
                    end
                    Qsm(u,k)=Qfin1(u,j);
                    Ism(u,k)=Ifin1(u,j);
                    k=k+1;
                end
                FQ=Qsm(u,1:k-1);
                FI=Ism(u,1:k-1);
                Fl=length(FQ);
                [A,B,~]=LSFpow(FQ,FI,Fl);
                Ifin(i)=A*((Qfin(i))^B); % I values of this region are smoothed
        else % smoothing operation for the second third of data points
        k=1;
        T=1; % the number of points before and after an individual data point from which the slope of the individual data point is calculated
        TT=2*T+1;
        for t=1:TT
            j=i-1+t-T;
            if j > nfin
                j=nfin;
                k=k-1;
            elseif j <= 1
                j=1;
                k=1;
            end
            Qsm(u,k)=Qfin1(u,j);
            Ism(u,k)=Ifin1(u,j);
            k=k+1;
        end
        FQ=Qsm(u,1:k-1);
        FI=Ism(u,1:k-1);
        Fl=length(FQ);
        [A,B,~]=LSFpow(FQ,FI,Fl);
        Ifin(i)=A*((Qfin(i))^B); % I values of this region are smoothed
        end
    end
    
    %%slope for pore fractals
    Qslpm1=0.0003; % upper cut-off for calculating the slope of pore fractals
    Qslpm2=0.003; % lower cut-off for calculating the slope of pore fractals
    pfdupper(u,1)=Qslpm1; % upper cut-off is reported in output
    pfdlower(u,1)=Qslpm2; % lower cut-off is reported in output
    for i=1:nfin
        if Qfin(i) >= Qslpm1
           break 
        end
    end
    qslpm1=i; islpm1=i;
    for i=1:nfin
        if Qfin(i) >= Qslpm2
            break
        end
    end
    qslpm2=i; islpm2=i;
    FQ=Qfin(qslpm1:qslpm2); FI=Ifin(islpm1:islpm2); Fl=length(FQ);
    [~,B,~]=LSFpow(FQ,FI,Fl);
    Smass=B; % slope of pore fractals
    Dporefract=-B; % pore fractal dimension
    
    %%slope for surface fractals
    sfdupper(u,1)=0; % upper cut-off is reported in output
    sfdlower(u,1)=0; % lower cut-off is reported in output
    Ssurf=0; % slope for surface fractals
    Dsurffract=0; % surface fractal dimension
    
    %%general slope
    Qslp1=0.0003; % upper cut-off for calculating the general slope
    Qslp2=0.003; % lower cut-off for calculating the general slope
    slopupper(u,1)=Qslp1; fdupper(u,1)=Qslp1; % upper cut-off is reported in output
    sloplower(u,1)=Qslp2; fdlower(u,1)=Qslp2; % lower cut-off is reported in output
    for i=1:nfin
        if Qfin(i) >= Qslp1
           break 
        end
    end
    qslp1=i; islp1=i;
    for i=1:nfin
        if Qfin(i) >= Qslp2
            break
        end
    end
    qslp2=i; islp2=i;
    FQ=Qfin(qslp1:qslp2); FI=Ifin(islp1:islp2); Fl=length(FQ);
    [A,B,r2]=LSFpow(FQ,FI,Fl);
    Sgenr=B; % general slope
    Dfract=B+6; % surface fractal dimension
    
    %%reports
    Slope(3,u)=0; Slope(1,u)=Smass; Slope(2,u)=Ssurf; Slope(3,u)=Sgenr; % slopes are reported
    FractalDim(3,u)=0; FractalDim(1,u)=Dporefract; FractalDim(2,u)=Dsurffract; FractalDim(3,u)=Dfract; % fractal dimensions are reported
    Ib(2,u)=0; Ib(1,u)=Ibckvsas; Ib(2,u)=Ibcksas; % background values are reported
    Nfinl(u,1)=nfin; % the number of total data points
    Qtr(u,1:Nfinl(u,1))=Qfin(1:Nfinl(u,1)); % manipulatd Q values
    Itr(u,1:Nfinl(u,1))=Ifin(1:Nfinl(u,1)); % manipulated I values
    dItr(u,1:Nfinl(u,1))=dIfin(1:Nfinl(u,1)); % manipulated I values
    Qgraph=Qtr(u,1:Nfinl(u,1)); Igraph=Itr(u,1:Nfinl(u,1)); % the figure is displayed in cmmand window
    figure 
    loglog(Qv, Iv, 'r^', 'MarkerSize',8 ,'DisplayName', 'VSAS Raw Data')
    hold on
    loglog(Qgraph, Igraph, 'ko', 'MarkerSize',5 ,'MarkerfaceColor','k','DisplayName', 'Manipulated VSAS Data')
    xlabel('Q, Å^-^1')
    ylabel('I(Q), cm^-^1')
    title(['Manipulated VSAS data',SN(u)])
    legend('show')
    legend('Location','northeast')
    legend('boxoff')
    hold off
end
fprintf('========================================\n')
fprintf('No\t Sample Name\t IBG_VSAS\t IBG_SAS\n')
fprintf('========================================\n')
for u=1:NSheet % the table is reported in the command window
    fdfd=char(SN(u));
    fprintf('%d\t ',u)
    fprintf([fdfd '\t         '])
    fprintf('%4.3f\t  %4.3f\n', Ib(1,u), Ib(2,u))
end
fprintf('========================================\n')
fprintf('\n')
fprintf('Data have been manipulated. Proceed to the "data analysis" module.\n')
fprintf('\n')