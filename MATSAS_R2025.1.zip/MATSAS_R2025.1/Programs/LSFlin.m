function [a,b,r2]=LSFlin(FQ,FI,FL)
%%Linear Least Squares Fitting
SUM1=0; SUM2=0; SUM3=0; SUM4=0; SUM5=0;
for lin=1:FL
   F1=SUM1+FQ(lin); SUM1=F1;
   F2=SUM2+FI(lin); SUM2=F2;
   F3=SUM3+FQ(lin)^2; SUM3=F3;
   F4=SUM4+FQ(lin)*FI(lin); SUM4=F4;
   F5=SUM5+FI(lin)^2; SUM5=F5;
end
a=(F2*F3-F1*F4)/(FL*F3-(F1^2)); %Intercept
b=(FL*F4-F1*F2)/(FL*F3-(F1^2)); %Slope
r2=(F4-F1*F2)^2/((F3-(FL*(F1/FL)^2))*(F5-(FL*(F2/FL)^2))); %correlation coefficient
end