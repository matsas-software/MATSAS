clear
close all
format longE
clc

fprintf('Select input data files. The input data must be prepared in csv, xls, and/or xlsx formats.\n')

[myFiles, path] = uigetfile( ...
    {'*.xlsx';'*.xls';'*.csv';'*.*'}, ...
    'Select One or More Files', ...
    'MultiSelect', 'on'); % Select multiple files

% User cancelled
if isequal(myFiles, 0)
    disp('User selected Cancel');
    return;
end

% Empty selection (very unlikely if not cancelled, but kept for safety)
if isempty(myFiles)
    fprintf('The format of input data is not supported. Prepare input data in xls(x) or csv format.\n')
    return;
end

% Ensure we always have a string array of file names
myFiles = string(myFiles);
NSheet  = numel(myFiles); % number of samples

fprintf('==============================================\n')
fprintf('No   file name                     sample name\n')
fprintf('==============================================\n')

for u = 1:NSheet
    filename = myFiles(u);               % string scalar
    fullName = fullfile(path, filename); % robust path join

    % Read numeric data from the file
    dataset = readmatrix(fullName);      % numeric data from csv/xls/xlsx

    % Number of rows (safer than length(dataset))
    nRows   = size(dataset, 1);
    L(u)    = nRows;

    % VSAS data: Q, I, dI (rows 9:end, columns 1:3)
    QV(1:nRows-8, u)  = dataset(9:nRows, 1); % VSAS Q-values
    IV(1:nRows-8, u)  = dataset(9:nRows, 2); % VSAS I-values
    dIV(1:nRows-8, u) = dataset(9:nRows, 3); % VSAS dI-values

    % SAS data: Q, I, dI (rows 9:end, columns 4:6)
    QS(1:nRows-8, u)  = dataset(9:nRows, 4); % SAS Q-values
    IS(1:nRows-8, u)  = dataset(9:nRows, 5); % SAS I-values
    dIS(1:nRows-8, u) = dataset(9:nRows, 6); % SAS dI-values

    % --- Read sample name from cell B1 ---
    [~, ~, ext] = fileparts(filename);

    if any(strcmpi(ext, [".xls", ".xlsx"]))
        % Spreadsheet file: we can specify Sheet and Range
        raw = readcell(fullName, 'Sheet', u, 'Range', 'B1');
    else
        % CSV or other text-like file: no Sheet, only Range is valid
        raw = readcell(fullName, 'Range', 'B1');
    end

    % raw is typically a 1x1 cell with the sample name
    if iscell(raw)
        SmplName = raw{1};
    else
        SmplName = raw; % fallback, in case readcell returns direct content
    end

    SN(u) = string(SmplName); % sample name as string

    % Other parameters from header rows
    rhom(1, u)   = dataset(2, 2); % scattering length/electron density (matrix)
    rhop(1, u)   = dataset(3, 2); % scattering length/electron density (pore)
    gd(1, u)     = dataset(4, 2); % solid density
    upsiz(1, u)  = dataset(5, 2); % smallest Q cut-off
    lowsiz(1, u) = dataset(6, 2); % largest Q cut-off

    % Prepare sample name for printing
    dfdf = char(SN(u));

    % Print sample index 'u' 
    fprintf('%d    ', u)
    fprintf('%s                     %s\n', char(filename), dfdf)
end

fprintf('==============================================\n')
fprintf('\n')
fprintf('Data have been imported. Proceed to the "data manipulation" module.\n')
fprintf('\n')