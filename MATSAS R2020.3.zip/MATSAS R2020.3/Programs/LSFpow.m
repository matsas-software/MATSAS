function [A,B,r2]=LSFpow(FQ,FI,Fl)
%%Least Squares Fitting-Power Law
SUM1=0; SUM2=0; SUM3=0; SUM4=0; SUM5=0;
for pow=1:Fl
   F1=SUM1+log(FQ(pow))*log(FI(pow));SUM1=F1;
   F2=SUM2+log(FQ(pow));SUM2=F2;
   F3=SUM3+log(FI(pow));SUM3=F3;
   F4=SUM4+(log(FQ(pow)))^2;SUM4=F4;
   F5=SUM5+(log(FI(pow)))^2;SUM5=F5;
end
F1;F2;F3;F4;F5;
b=((Fl*F1)-(F2*F3))/((Fl*F4)-F2^2);
a=(F3-b*F2)/Fl;
A=exp(a);%coefficient
B=b;%exponential component
r2=((F1-((F2*F3)/Fl))^2)/((F4-((F2^2)/Fl))*(F5-((F3^2)/Fl)));
end