clear
close all
format longE
clc
NSheet=1; % one sample can be imported from CSV file only
clc
fprintf('==============================================\n')
fprintf('No   file name                     sample name\n')
fprintf('==============================================\n')
for u=1:NSheet
filename='input.csv'; % filename is addressed
sheet=u; % sheet number is addressed
dataset=readmatrix(filename); % numeric data are called from the CSV file 
L(u)=length(dataset); % the number of elements is found
QV(1:L(u)-7,u)=dataset(8:L(u),1); % VSAS Q-values are imported 
IV(1:L(u)-7,u)=dataset(8:L(u),2); % VSAS I-values are imported 
QS(1:L(u)-7,u)=dataset(8:L(u),3); % SAS Q-values are imported 
IS(1:L(u)-7,u)=dataset(8:L(u),4); % SAS I-values are imported 
[num,txt,raw]=xlsread(filename,sheet,'B1'); % sample name is called from MS Excel sheet(s)
SmplName=cell(raw); SN(u)=string(SmplName); % sample name is imported as a string component
rhom(1,u)=dataset(1,2); % scattering length/electron density of phase 1 (solid/matrix) is imported
rhop(1,u)=dataset(2,2); % scattering length/electron density of phase 2 (scatterer/pore) is imported
gd(1,u)=dataset(3,2); % solid density is imported
upsiz(1,u)=dataset(4,2); % upper cut-off is imported
lowsiz(1,u)=dataset(5,2); % lower cut-off is imported
dfdf=char(SN(u)); % string component is converted to character component
fprintf('%d    ',sheet) % the number of sample is displayed
fprintf([filename '                     ' dfdf '\n']) % the message states that the data file is imported if appeard
end
fprintf('==============================================\n')
fprintf('\n')
fprintf('Data have been imported. Proceed to the "data manipulation" module.\n')
fprintf('\n')