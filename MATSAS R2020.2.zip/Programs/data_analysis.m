close all
Nitr=2; %number of iterations is given
chi2tol=1e-3; %chi-squared tolerance is given
prompt='Number of iterations terminates the fitting operation? Y/N [Y]:';
method=input(prompt,'s');
if isempty(method) || method == 'Y' %the termination method of fitting operation is selected
  terminator1=Nitr;
  terminator2=0;
else
    terminator1=1;
    terminator2=chi2tol;
end
for u=1:NSheet
Nfn=Nfinl(u,1); % the number of scattering vectors
%%bin size distribution
Ri(u,1)=2.5/Qtr(u,Nfn); % minimum size of scatterers (radius)
Rf(u,1)=2.5/Qtr(u,1); % maximum size of scatterers (radius)
logRi=log10(Ri(u,1)); % minimum size transformed to logarithmic form
logRf=log10(Rf(u,1)); % maximum size transformed to logarithmic form
Nbin=49; % the number of bins
nfn=Nbin+1; 
nfout(u,1)=nfn;
logint=(logRf-logRi)/Nbin; % the size of bin (logarithmic form)
logR(u,1)=logRi; % the centre of first bin (minimum scatterer size) is generated
for i=2:nfn % bin size distribution operation
    logR(u,i)=logR(u,i-1)+logint; % all bins centred
end
logR(u,nfn)=logRf; % the centre of last bin (maximum scatterer size) is generated
Q(u,1)=0; I(u,1)=0; dI(u,1)=0;
k=nfn;
for i=1:nfn % I-Q values of each bin are found
    Q(u,i)=2.5/(10^logR(u,k)); % the relationship between the scattering vector and scatterer size based on the Radlinski approximation (2002)
    k=k-1;
    for j=1:Nfn
        if round(Q(u,i),10) == round(Qtr(u,j),10)
           I(u,i)=Itr(u,j);
           dI(u,i)=dItr(u,j);
           break
        elseif Q(u,i) < Qtr(u,j)
               FQ=log10(Qtr(u,j-1:j));
               FI=log10(Itr(u,j-1:j));
               FL=length(FQ);
               [a,b,r2]=LSFlin(FQ,FI,FL);
               I(u,i)=10^(a+b*log10(Q(u,i)));
               FQ=log10(Qtr(u,j-1:j));
               FI=log10(dItr(u,j-1:j));
               FL=length(FQ);
               [a,b,r2]=LSFlin(FQ,FI,FL);
               dI(u,i)=10^(a+b*log10(Q(u,i)));
               break
        end
    end
end
logr(u,1)=0; logrmin(u,1)=0; logrmax(u,1)=0; % the centre, maximum, and minimum of bins are generated
k1=2; k2=1; k3=1;
qno=1;
for i=nfn:-qno:2 % the centre, maximum, and minimum of bins are calculated based on the Radlinski approximation (2002)
    rk1=log10(2.5/Q(u,i));
    rk2=log10(2.5/Q(u,i-1));
    logrmin(u,k1)=(rk1+rk2)/2; % the minimum limit of each bin
    logr(u,k2)=rk1; % the centre of each bin
    logrmax(u,k3)=(rk1+rk2)/2; % the maximum of each bin
    k1=k1+1; k2=k2+1; k3=k3+1;
end
cno=nfn;
logrmin(u,1)=2*logr(u,1)-logrmin(u,2); % the extra fractional size of first bin is discarded
logr(u,k2)=log10(2.5/Q(u,1));
logrmax(u,k2)=2*logr(u,k2)-logrmax(u,k2-1); % the extra fractional size of last bin is discarded
R(u,1)=0; Rmin(u,1)=0; Rmax(u,1)=0;
for i=1:cno % the centre, maximum, and minimum of bins are transformed from logarithmic form to normal values
    Rmin(u,i)=10^logrmin(u,i);
    R(u,i)=10^logr(u,i);
    Rmax(u,i)=10^logrmax(u,i);
end

%%IQ0 and fr calculation
cr=cno; % the number of Qs that is equal to the number of bins
Qfr(u,1)=0; Ifr(u,1)=0; % I-Q values are generated to calculated fr 
Q2fr(u,1)=0; lnIfr(u,1)=0; % Q2 and ln(I) are generated to calculated IQ0
S(u,1)=0; fD(u,1)=0;  % slope and fractal dimension of each bin are generated
logIQ0(u,1)=0; IQ0(u,1)=0; % logIQ0 and IQ0 are generated
for i=1:cr % IQ0 is calculated based on the Guinier approximation
    k=1;
    for t=1:qno+2
        j=nfn-(i*qno)-1+t;
        if j > nfn
            j=nfn;
            k=k-1;
        elseif j <= 1
            j=1;
            k=1;
        end
        Qfr(u,k)=Q(u,j);
        Ifr(u,k)=I(u,j);
        Q2fr(u,k)=(Q(u,j))^2;
        lnIfr(u,k)=log(I(u,j));
        k=k+1;
    end
    FQ=Qfr(u,1:k-1);
    FI=Ifr(u,1:k-1);
    Fl=length(FQ);
    [A,B,r2]=LSFpow(FQ,FI,Fl);
    S(u,i)=B; % slope of data points within each bin
    fD(u,i)=6+B; % fractal dimension of data points within each bin
    FQ=Q2fr(u,1:k-1); % Q2
    FI=lnIfr(u,1:k-1); %ln(I)
    FL=length(FQ);
    [a,b,r2]=LSFlin(FQ,FI,FL); % linear regression is used to find the intercept from the Guinier approximation
    logIQ0(u,i)=a; % intercept of linear regression is logarithmic form of IQ0
    IQ0(u,i)=exp(logIQ0(u,i)); % IQ0 is calculated
end
log10dfr(u,1)=0; 
dfr(u,1:cr)=0; % dfr is generated
SUMdfr=0;
for p1=1:cr % calculating dfr
    log10dfr(u,p1)=log10(fD(u,p1)*dI(u,p1)/IQ0(u,p1)); % dfr is related to fractal dimension (fD) and the Guinier approximation (IQ0)
    dfr(u,p1)=10^log10dfr(u,p1); % dfr is calculated
    SUMdfr=SUMdfr+dfr(u,p1); 
end
Sdfr(u,1)=SUMdfr; % summation of dfr
frnorm(u,1)=0; fr(u,1)=0; % normalised fr and fr are generated
for p2=1:cr % calculating normalised fr and fr
    frnorm(u,p2)=dfr(u,p2)/Sdfr(u,1); % normalised fr is calculated
    fr(u,p2)=frnorm(u,p2)/(Rmax(u,p2)-Rmin(u,p2)); % fr is calculated
end

%%Fitting Operation
Vrmean(u,1)=0; Vr2mean(u,1)=0; % mean/average scatterer volume and mean/average squared scatterer volume are generated
ifit(1,1)=0; IFIT(u,1)=0; % fitting variables are generated
ssq=0; SSQ(u,1)=1; SSQOUT(u,1)=0; % the variables of the summation of squared errors are generated
diff(u,1)=1;  chi2(u,1)=0; CHI2(u,1)=0; % difference variables are generated
IQo(u,1)=0; Fr(u,1)=0; % final variables of IQo and Fr are generated
iteration=0; % counting iterations
Nitr_initial=0; % initial prompt for while loop if iteration is selected
chi2tol_initial=1; % initial prompt for while loop if chi squared is selected
while Nitr_initial < terminator1 && chi2tol_initial > terminator2 
for i=1:cr % mean (squared) scatterer volume calculation operation
    int1=Rmin(u,i); % lower band (the minimum size of each bin) of integration
    int2=Rmax(u,i); % upper band (the maximum size of each bin) of integration
    Intg1=1/3*pi*(int2^4-int1^4)*fr(u,i); % integration of mean scatterer volume
    Intg2=1/7*(4/3*pi)^2*(int2^7-int1^7)*fr(u,i); % integration of mean squared scatterer volume
    Vrmean(u,i)=(10^-24)*Intg1; % mean scatterer volume
    Vr2mean(u,i)=(10^-48)*Intg2; % mean squared scatterer volume
end
ssq=0;
sumchi2=0;
for i=1:nfn % main body of the fitting operation - addressing I-Q values
    SUMFIT=0;
        for j=1:cr % addressing bins 
            int1=Rmin(u,j); % lower band (the minimum size of each bin) of integration
            int2=Rmax(u,j); % upper band (the maximum size of each bin) of integration
            Intgfit2=(Q(u,i)^-7)*((16*pi^2)*(-5/4*sin(Q(u,i)*int2)*cos(Q(u,i)*int2)+3/2*Q(u,i)*int2*cos(Q(u,i)*int2)^2+Q(u,i)^2*int2^2*(0.5*sin(Q(u,i)*int2)*cos(Q(u,i)*int2)+0.5*Q(u,i)*int2)-0.25*Q(u,i)*int2-1/3*Q(u,i)^3*int2^3)); % upper band of the integration of scatterer volume distribution
            Intgfit1=(Q(u,i)^-7)*((16*pi^2)*(-5/4*sin(Q(u,i)*int1)*cos(Q(u,i)*int1)+3/2*Q(u,i)*int1*cos(Q(u,i)*int1)^2+Q(u,i)^2*int1^2*(0.5*sin(Q(u,i)*int1)*cos(Q(u,i)*int1)+0.5*Q(u,i)*int1)-0.25*Q(u,i)*int1-1/3*Q(u,i)^3*int1^3)); % lower band of the integration of scatterer volume distribution
            Intgfit=fr(u,j)*(Intgfit2-Intgfit1); % integration of scatterer volume distribution
            ifit(i,j)=IQ0(u,j)*(Vr2mean(u,j)^-1)*(10^-48)*Intgfit; % I fitted for each scatterer and each bin
            SUMFIT=SUMFIT+ifit(i,j);
        end
        IFIT(u,i)=SUMFIT; % fitted I values; PDSP model
        diff(u,i)=log10(I(u,i))-log10(IFIT(u,i)); % logarithmic form of difference between measured I and fitted I
        chi2(u,i)=(log10(I(u,i))-log10(IFIT(u,i))).^2/log10(IFIT(u,i)); % chi squared between measured and fitted I values
        ssq=ssq+diff(u,i); % summation of squared errors for each scatterer
        sumchi2=sumchi2+chi2(u,i); % summation of chi squared errors for each scatterer
        SSQOUT(u,i)=ssq;
end
SSQ(u,1)=ssq; % summation of squared errors
CHI2(u,1)=sumchi2; % summation of chi squared errors
IQo(u,1:cr)=IQ0(u,1:cr);
Fr(u,1:cr)=fr(u,1:cr);

for i=1:cr % interpolation operation
    j=cr+1-i;
    IQ0(u,i)=(I(u,j)*IQ0(u,i))/IFIT(u,j); % the interpolated IQ0 is found for each scatterer
end

SUMdfr=0;
for p1=1:cr % dfr updating operation 
    log10dfr(u,p1)=log10(fD(u,p1)*dI(u,p1)/IQ0(u,p1));
    dfr(u,p1)=10^log10dfr(u,p1); % dfr is updated for next iteration
    SUMdfr=SUMdfr+dfr(u,p1);
end
Sdfr(u,1)=SUMdfr;
for p2=1:cr % normalised fr and fr updating operation
    frnorm(u,p2)=dfr(u,p2)/Sdfr(u,1); % normalised fr is updated for next iteration
    fr(u,p2)=frnorm(u,p2)/(Rmax(u,p2)-Rmin(u,p2)); % fr is updated for next iteration
end
if isempty(method) || method == 'Y'
   Nitr_initial=Nitr_initial+1;
else
    chi2tol_initial=abs(sumchi2);
end
iteration=iteration+1;
end
SSQabs(u,1)=abs(SSQ(u,1)); % final summation of squared errors is found and reported in output
CHI2abs(u,1)=abs(CHI2(u,1)); % final summation of chi squared errors is found and reported here
Iteration(u,1)=iteration; % the number of iterations is reported in output 

%%RESULTS
%Specific Surface Area (SSA) [m2/g]
SSA(u,1)=0;
for i=1:cr
    int1=Rmin(u,i); % lower band of integration
    int2=Rmax(u,i); % upper band of integration
    Intg3=4/3*pi*(int2^3-int1^3)*Fr(u,i); % the integration of SSA of scatterers or the integration of pore (scatterer) area
    SSA(u,i)=(gd(1,u)^-1)*(10^-4)*IQo(u,i)*((rhom(1,u)-rhop(1,u))^-2)*(Vr2mean(u,i)^-1)*(10^-16)*Intg3; % SSA is calculated for each bin
end
SSAcum(u,1)=0; SSAC=0;
for i=1:cr
    SSAC=SSAC+SSA(u,i);
    SSAcum(u,i)=SSAC; % cumulative SSA is found for each bin
end
SSAt(u,1)=SSAC; %cumulative specific surface area
SSAmeso(u,1)=interp1(R(u,1:cr),SSAcum(u,1:cr),250,'spline'); %Mesopore Area up to 50nm
SSAmeso25(u,1)=interp1(R(u,1:cr),SSAcum(u,1:cr),125,'spline'); %Mesopore Area up to 25nm
SSAmeso10(u,1)=interp1(R(u,1:cr),SSAcum(u,1:cr),50,'spline'); %Mesopore Area up to 10nm
SSAmeso5(u,1)=interp1(R(u,1:cr),SSAcum(u,1:cr),25,'spline'); %Mesopore Area up to 5nm
SSAmacro(u,1)=SSAt(u,1)-SSAmeso(u,1); %Macropore Area
dR(u,1)=0; dlogr(u,1)=0; ds(u,1)=0; 
dsdr(u,1)=0; dsdlogr(u,1)=0;
psd=cr-1;
npsd(u,1)=psd;
k=1;
for i=1:psd
    dR(u,i)=R(u,k)-R(u,k+1);
    dlogr(u,i)=log10(R(u,k))-log10(R(u,k+1));
    ds(u,i)=SSAcum(u,k)-SSAcum(u,k+1);
    dsdr(u,i)=ds(u,i)/dR(u,i); % differential pore area is found
    dsdlogr(u,i)=ds(u,i)/dlogr(u,i); % logarithmic differential pore area is found
    k=k+1;
end
%Porosity [%]
phi(u,1)=0;
for i=1:cr
    phi(u,i)=100*IQo(u,i)*Vrmean(u,i)*((rhom(1,u)-rhop(1,u))^-2)*(Vr2mean(u,i)^-1); % porosity of each bin or incremental porosity is found
end
phicum(u,1)=0; PHC=0; 
for i=1:cr
    PHC=PHC+phi(u,i);
    phicum(u,i)=PHC; % cumulative porosity is found for each bin
end
PHIt(u,1)=PHC;%cumulative porosity
PHImeso(u,1)=interp1(R(u,1:cr),phicum(u,1:cr),250,'spline'); %Mesoporosity up to 50nm
PHImeso25(u,1)=interp1(R(u,1:cr),phicum(u,1:cr),125,'spline'); %Mesoporosity up to 25nm
PHImeso10(u,1)=interp1(R(u,1:cr),phicum(u,1:cr),50,'spline'); %Mesoporosity up to 10nm
PHImeso5(u,1)=interp1(R(u,1:cr),phicum(u,1:cr),25,'spline'); %Mesoporosity up to 5nm
PHImacro(u,1)=PHIt(u,1)-PHImeso(u,1); %Macroporosity
%pore (scatterer) volume [cm3/g]
Vp(u,1)=0; VHC=0; Vcum(u,1)=0;
for i=1:cr
    Vp(u,i)=(0.01*phi(u,i))/(gd(1,u)*(1-(0.01*phi(u,i)))); % the pore volume of each bin is found
    VHC=VHC+Vp(u,i);
    Vcum(u,i)=VHC; % the cumulative pore volume of each bin is found
end
Vcumt(u,1)=VHC;%cumulative pore volume
Vmeso(u,1)=interp1(R(u,1:cr),Vcum(u,1:cr),250,'spline'); %Mesopore Volume up to 50nm
Vmeso25(u,1)=interp1(R(u,1:cr),Vcum(u,1:cr),125,'spline'); %Mesopore Volume up to 25nm
Vmeso10(u,1)=interp1(R(u,1:cr),Vcum(u,1:cr),50,'spline'); %Mesopore Volume up to 10nm
Vmeso5(u,1)=interp1(R(u,1:cr),Vcum(u,1:cr),25,'spline'); %Mesopore Volume up to 5nm
Vmacro(u,1)=Vcumt(u,1)-Vmeso(u,1); %Macropore Volume
dR(u,1)=0; dlogr(u,1)=0; dv(u,1)=0; 
dvdr(u,1)=0; dvdlogr(u,1)=0;
psd=cr-1;
k=1;
for i=1:psd
    dR(u,i)=R(u,k)-R(u,k+1);
    dlogr(u,i)=log10(R(u,k))-log10(R(u,k+1));
    dv(u,i)=Vcum(u,k)-Vcum(u,k+1);
    dvdr(u,i)=dv(u,i)/dR(u,i); % differential pore volume is found
    dvdlogr(u,i)=dv(u,i)/dlogr(u,i); % logarithmic differential pore volume is found
    k=k+1;
end
%Sensitivity Analysis
Diam(u,1)=0; LOGDiam(u,1)=0; dSSQUOT(u,1)=0; dlogIQo(u,1)=0; dSSQdlogIQo(u,1)=0;
FRnm(u,1)=0; D3FR(u,1)=0;
psd=cr-1;
k=1;
%error analysis 
for i=1:psd 
    Diam(u,i)=0.2.*R(u,i);
    LOGDiam(u,i)=log10(Diam(u,i));
    dSSQUOT(u,i)=SSQOUT(u,k+1)-SSQOUT(u,k);
    dlogIQo(u,i)=log10(IQo(u,k+1))-log10(IQo(u,k));
    dSSQdlogIQo(u,i)=dSSQUOT(u,i)/dlogIQo(u,i); % dSSQ/dlog(IQ0) is found
    k=k+1;
end
%volume-weighed scatterer size distribution
for i=1:cr
    Diam(u,i)=0.2.*R(u,i);
    FRnm(u,i)=10.*Fr(u,i);
    D3FR(u,i)=(Diam(u,i)^3)*FRnm(u,i); % D^3f(r) is found
end

%%Report
%scattering data
figure(1)
XQplot=Q(u,1:nfn); 
YIplot=I(u,1:nfn); 
SNU1=char(SN(u));
YIFplot=IFIT(u,1:nfn); 
XRplot=2.5./R(u,1:cr); 
YIQ0plot=IQo(u,1:cr); 
loglog(XQplot,YIplot,'o','Linewidth',1,'DisplayName',['Measured ' SNU1]) % I-Q curve manipulated is displyed
hold on
loglog(XQplot,YIFplot,'.-','Linewidth',1,'DisplayName',['PDSP ' SNU1]) % I-Q curve PDSP model fitted is displayed
hold on
loglog(XRplot,YIQ0plot,'*','DisplayName',['IQ_0 ' SNU1]) % IQ0-Q curve is displayed 
xlabel('Q, �^-^1','FontSize',11,'FontWeight','bold')
ylabel('I(Q), cm^-^1','FontSize',11,'FontWeight','bold')
title('Fitted PDSP Model')
hold on
legend('show')
legend('Location','northeast')
legend('boxoff')
%probability function of the scatterer (pore) size distribution
figure(2)
XFrplot=0.2.*R(u,1:cr); YFrplot=10.*Fr(u,1:cr); SNU2=char(SN(u));
loglog(XFrplot,YFrplot,'d-','Linewidth',1,'DisplayName',SNU2) % f(r) curve is displayed
xlabel('Pore Diameter, nm','FontSize',11,'FontWeight','bold')
ylabel('f(r), nm^-^1','FontSize',11,'FontWeight','bold')
title('Probability Function of the Scatterer (Pore) Size Distribution')
hold on
legend('show')
legend('Location','northeast')
legend('boxoff')
%error analysis
figure(3)
XdSSQdIQoplot=LOGDiam(u,1:psd); 
YdSSQdIQoplot=dSSQdlogIQo(u,1:psd); 
SNU16=char(SN(u));
plot(XdSSQdIQoplot,YdSSQdIQoplot,'d-','Linewidth',1,'DisplayName',SNU16) % dSSQ/dlogD curve is displayed
ylim([-5 5]) % y-axis is limited between -5 and +5
xlabel('log(D)','FontSize',11,'FontWeight','bold') 
ylabel('dSSQ/dlog(IQ0)','FontSize',11,'FontWeight','bold') 
title('Error Analysis')
hold on
legend('show')
legend('Location','northeast')
legend('boxoff')
end
fprintf('==========================================================================================================================\n')
fprintf('No\t Sample Name\t Slope\t Ds\t Dp\t SSA(m2/g)\t Scatterer (Pore) Volume(cm3/g)\t Porosity(%%)\t SSQ\t Chi2\t Iteration\n')
fprintf('==========================================================================================================================\n')
for u=1:NSheet
fddf=char(SN(u));
fprintf('%d\t ',u)
fprintf([fddf '\t   '])
fprintf('%4.2f\t  %4.2f\t  %4.2f\t  %4.1f\t  %4.4f\t  %4.1f\t  %4.2f\t  %4.6f\t  %4.f\n', Slope(3,u), FractalDim(2,u), FractalDim(1,u), SSAt(u,1), Vcumt(u,1), PHIt(u,1), SSQabs(u,1), CHI2abs(u,1), Iteration(u,1))
end
fprintf('==========================================================================================================================\n')
fprintf('\n')
fprintf('Data have been analysed. Proceed to the "data output" module.\n')
fprintf('\n')