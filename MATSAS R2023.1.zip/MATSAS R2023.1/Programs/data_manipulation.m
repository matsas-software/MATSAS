for u=1:NSheet
%%call for data
l=L(u)-7;
Qv=zeros(l,1); Iv=zeros(l,1); dIv=zeros(l,1); Qs=zeros(l,1); Is=zeros(l,1); dIs=zeros(l,1); 
Qv=QV(:,u)'; %VSAS Q-values are placed in a single row matrix
Iv=IV(:,u)'; %VSAS I-values are placed in a single row matrix
dIv=dIV(:,u)'; %VSAS dI-values are placed in a single row matrix
Qs=QS(:,u)'; %SAS Q-values are placed in a single row matrix
Is=IS(:,u)'; %SAS I-values are placed in a single row matrix
dIs=dIS(:,u)'; %SAS dI-values are placed in a single row matrix

%non-numeric elements of VSAS data are discarded
findv=find(Qv(1:end)>0); 
findv1=findv(1); 
findv2=findv(end);
Qv=Qv(findv1:findv2); %VSAS numeric Q-values are denoted
Iv=Iv(findv1:findv2); %VSAS numeric I-values are denoted
dIv=dIv(findv1:findv2); %VSAS numeric dI-values are denoted

%non-numeric elements of SAS data are discarded
finds=find(Qs(1:end)>0);
finds1=finds(1); 
finds2=finds(end);
Qs=Qs(finds1:finds2); %SANS numeric Q-values are employed now
Is=Is(finds1:finds2); %SANS numeric I-values are employed now
dIs=dIs(finds1:finds2); %SANS numeric dI-values are employed now

QVmeas=Qv; IVmeas=Iv; dIVmeas=dIv; % unprocessed VSAS data
QSmeas=Qs; ISmeas=Is; dISmeas=dIs; % unprocessed SAS data

%%overlap area
m=length(Qv);
n=length(Qs);
vi=1;
vf=m;
si=1;
sf=n;
for i=vi:vf %first data point of VSAS in overlap area is found
    if Qv(i) > Qs(si)
        break
    end
end
for j=si:sf %last data point of SAS in overlap area is found
    if Qs(j) > Qv(vf)
    break
    end
end
ivolp=i; fvolp=m; %initial and final arrays of VSAS data in overlap area are found 
isolp=1; fsolp=j; %initial and final arrays of SAS data in overlap area are found 
qisolp=Qs(isolp); qfvolp=Qv(fvolp);

%%noise removal of VSAS data in overlap area
Qvfo=Qv(vi+50:fvolp); Ivfo=Iv(vi+50:fvolp); % last 50 I-Q values of VSAS are processed for noise removal
FQ=Qvfo; FI=Ivfo; Fl=length(Qvfo); % inputs for the LSFpow function: slope and intercept of the data points selected outside the overlap area are found
[A,B,r2]=LSFpow(FQ,FI,Fl);
Qvd=Qv(ivolp:fvolp); Ivd=Iv(ivolp:fvolp); dIvd=dIv(ivolp:fvolp); md=length(Qvd);
Ivdfit=zeros(1,md); erv=zeros(1,md); Qvdfit=Qvd;
for k=1:md
    Ivdfit(k)=A*((Qvdfit(k))^B); % the power law model is fitted to the data points selected inside the overlap area 
    erv(k)=log(Ivd(k))-log(Ivdfit(k)); % error is found for the individual data points
    erv(k)=abs(erv(k)); % absolute error is found for the individual data points
end
ervm=max(erv); % maximum of the absolute errors is found
dvp=100; % the percentage of data points being less than maximum error that is remained
cervm=0.01*dvp*ervm;
Qvds=zeros(1,md); Ivds=zeros(1,md); dIvds=zeros(1,md);
for k=1:md % noise removal operation
    if erv(k) <= cervm
       Qvds(k)=Qvd(k);
       Ivds(k)=Ivd(k);
       dIvds(k)=dIvd(k);
    end
end
IC=1:1:md; QSR=[Qvds;Ivds;dIvds;IC]; QSR=QSR'; QSR=sortrows(QSR,[1,4]); QSR=QSR'; % data are sorted after noise removal
Qvd=QSR(1,:); Ivd=QSR(2,:); dIvd=QSR(3,:);
findvd=find(Qvd>0); mvd1=findvd(1); mvd2=findvd(end); 
Qvd=Qvd(mvd1:mvd2); Ivd=Ivd(mvd1:mvd2); dIvd=dIvd(mvd1:mvd2);
Qvr=[Qv(vi:ivolp-1) Qvd]; Ivr=[Iv(vi:ivolp-1) Ivd]; dIvr=[dIv(vi:ivolp-1) dIvd]; mr=length(Qvr); % VSAS data for further manipulation

%%VSAS Background Subtraction
Qvlp1=0.0003; %upper cut-off for VSAS background subtraction
Qvlp2=0.003; %lower cut-off for VSAS background subtraction
vsasbkgrupper(u,1)=Qvlp1; %upper cut-off for VSAS background subtraction to be addressed in output
vsasbkgrlower(u,1)=Qvlp2; %lower cut-off for VSAS background subtraction to be addressed in output
for i=1:mr % finding first data point after upper cut-off
    if Qvr(i) >= Qvlp1
       break 
    end
end
qvlp1=i; ivlp1=i; % first data point is found
for i=1:mr % finding last data point before lower cut-off
    if Qvr(i) >= Qvlp2
        break
    end
end
qvlp2=i; ivlp2=i; % last data point is found
FQ=Qvr(qvlp1:qvlp2);FI=Ivr(ivlp1:ivlp2);Fl=length(FQ);
[A,B,r2]=LSFpow(FQ,FI,Fl); % the LSFpow model is fitted to the data points selected
B=(-B);
FQ=Qvr.^B; FI=(Qvr.^B).*Ivr; 
hbpv=30; % the percentage of first points to be removed for regression
hbv=round(0.01*hbpv*mr);
if hbv==0
    hbv=1;
end
FQ=FQ(hbv:mr); FI=FI(hbv:mr); FL=length(FQ); % final VSAS data points for background subtraction
[a,b,r2]=LSFlin(FQ,FI,FL); % the LSFlin model is used for background subtraction 
Ibckvsas=b; % slope is the background
Ivr=Ivr-Ibckvsas; % I values of VSAS are subtracted

%%noise removal of SAS data in overlap area
Qsfo=Qs(fsolp:fsolp+10); Isfo=Is(fsolp:fsolp+10); % first 10 I-Q values of SAS data points are processed for noise removal
FQ=Qsfo; FI=Isfo; Fl=length(Qsfo); % inputs for the LSFpow function: slope and intercept of the data points selected outside the overlap area are found
[A,B,r2]=LSFpow(FQ,FI,Fl);
sA=A; sB=B;
Qsd=Qs(isolp:fsolp); Isd=Is(isolp:fsolp); dIsd=dIs(isolp:fsolp);  nd=length(Qsd);
Isdfit=zeros(1,nd); ers=zeros(1,nd); Qsdfit=Qsd;
for k=1:nd
    Isdfit(k)=A*((Qsdfit(k))^B); % the power law model is fitted to the data points selected inside the overlap area 
    ers(k)=log(Isd(k))-log(Isdfit(k)); % error is found for the individual data points
    ers(k)=abs(ers(k)); % absolute error is found for the individual data points
end
ersm=max(ers); % maximum of the absolute errors is found
dsp=100; % the percentage of the data points being less than maximum error that is remained
cersm=0.01*dsp*ersm;
Qsds=zeros(1,nd); Isds=zeros(1,nd); dIsds=zeros(1,nd);
for k=1:nd % noise removal operation
    if ers(k) <= cersm
       Qsds(k)=Qsd(k);
       Isds(k)=Isd(k);
       dIsds(k)=dIsd(k);
    end
end
IC=1:1:nd; QSR=[Qsds;Isds;dIsds;;IC]; QSR=QSR'; QSR=sortrows(QSR,[1,4]); QSR=QSR'; % data are sorted after noise removal
Qsd=QSR(1,:); Isd=QSR(2,:); dIsd=QSR(3,:);
findsd=find(Qsd>0); nsd1=findsd(1); nsd2=findsd(end);
Qsd=Qsd(nsd1:nsd2); Isd=Isd(nsd1:nsd2); dIsd=dIsd(nsd1:nsd2);
Qsr=[Qsd Qs(fsolp+1:sf)]; Isr=[Isd Is(fsolp+1:sf)]; dIsr=[dIsd dIs(fsolp+1:sf)]; nsr=length(Qsr); % SAS data for further manipulation

%%SAS Background Subtraction
Qslp1=0.001; %upper cut-off for SAS background subtraction
Qslp2=0.2; %lower cut-off for SAS background subtraction
sasbkgrupper(u,1)=Qslp1; %upper cut-off for SAS background subtraction to be addressed in output
sasbkgrlower(u,1)=Qslp2; %lower cut-off for SAS background subtraction to be addressed in output
for i=1:nsr % finding first data point after upper cut-off
    if Qsr(i) >= Qslp1
       break 
    end
end
qslp1=i; islp1=i; % first data point is found
for i=1:nsr % finding last data point before lower cut-off
    if Qsr(i) >= Qslp2
        break
    end
end
qslp2=i; islp2=i; % last data point is found
FQ=Qsr(qslp1:qslp2);FI=Isr(islp1:islp2);Fl=length(FQ);
[A,B,r2]=LSFpow(FQ,FI,Fl); % the LSFpow model is fitted to the data points selected
B=(-B);
FQ=Qsr.^B; FI=(Qsr.^B).*Isr; 
hbp=50; % the percentage of first points to be removed for regression
hb=round(0.01*hbp*nsr);
if hb==0
    hb=1;
end
FQ=FQ(hb:nsr); FI=FI(hb:nsr); FL=length(FQ); % final SAS data points for background subtraction
[a,b,r2]=LSFlin(FQ,FI,FL); % the LSFlin model is used for background subtraction 
Ibcksas=b; % slope is the background
Isr=Isr-Ibcksas; % I values of SAS are subtracted

%%curve merging
Qso=Qsr(1:30); Iso=Isr(1:30); % the first 30 SAS data points is used to find the slope of SAS curve 
FQ=Qso; FI=Iso; Fl=length(Qso); % inputs for the LSFpow model 
[A,B,r2]=LSFpow(FQ,FI,Fl);
nmerg=30; % the number of last VSAS data points that is used for matching VSAS curve on SAS curve
Imerg=zeros(1,nmerg);
Qmerg=Qvr(mr+1-nmerg:mr);
for i=1:nmerg % the last 30 VSAS data points get the slope of the first 30 SAS data points
    Imerg(i)=A*((Qmerg(i))^B);
end
Ivrmean=mean(Ivr(mr+1-nmerg:mr)); % the average of VSAS I values is found
Imergmean=mean(Imerg); % the average of VSAS I values matched is found
fcm=Imergmean/Ivrmean; % match ratio is found
Icm=Ivr; nmatch=mr; Imatch=zeros(1,nmatch);
for i=1:nmatch % matching operation
    Imatch(i)=log10(Icm(i));
    Imatch(i)=Imatch(i)+log10(fcm);
    Imatch(i)=10^(Imatch(i));
end
Ivn=Imatch; Qvn=Qvr; % VSAS I-Q values after matching
Qcom=[Qvn Qsr]; % Q values of both VSAS and SAS curves are merged
Icom=[Ivn Isr]; % I values of both VSAS and SAS curves are merged
dIcom=[dIvr dIsr]; % I values of both VSAS and SAS curves are merged
ncom=length(Qcom);
ICcom=1:1:ncom; QSR=[Qcom;Icom;dIcom;ICcom]; QSR=QSR'; QSR=sortrows(QSR,[1,4]); QSR=QSR'; % data are sorted
Qcom=QSR(1,:); Icom=QSR(2,:); dIcom=QSR(3,:); % merged curve

%measured (un-manipulated) data report
Qmeasured=[QVmeas QSmeas]; % Q values of both VSAS and SAS curves unmanipulated are combined
Imeasured=[IVmeas ISmeas]; % I values of both VSAS and SAS curves unmanipulated are combined
nmeas=length(Qmeasured);
ICmeas=1:1:nmeas; QSR=[Qmeasured;Imeasured;ICmeas]; QSR=QSR'; QSR=sortrows(QSR,[1,3]); QSR=QSR'; % data are sorted
Qmeasured=QSR(1,:); Imeasured=QSR(2,:);
NFINAL(u,1)=nmeas;
QMEAS(u,1:NFINAL(u,1))=Qmeasured(1:NFINAL(u,1)); % the Q values unmanipulated to be reported in output or here
IMEAS(u,1:NFINAL(u,1))=Imeasured(1:NFINAL(u,1)); % the I values unmanipulated to be reported in output or here

%%data reduction
%smallest Q cut-off
if upsiz(1,u)> 0
   Qucoff=upsiz(1,u); % the smallest Q cut-off is called
else
    Qucoff=Qcom(1); % otherwise, the smallest Q cut-off is the first Q value
end
for i=1:ncom % upper cut-off finding operation
    if Qcom(i) > Qucoff && i==1
       upp=i;
       break
    elseif Qcom(i) == Qucoff
           upp=i;
           break
    elseif Qcom(i) > Qucoff
           FQ=[log10(Qcom(i-1)) log10(Qcom(i))]; 
           FI=[log10(Icom(i-1)) log10(Icom(i))]; 
           FL=2;
           [a,b,r2]=LSFlin(FQ,FI,FL);
           Iucoff=10^(a+b*log10(Qucoff));
           Qcom(i-1)=Qucoff; Icom(i-1)=Iucoff;
           upp=i-1;
           break
    end
end
Qupd=Qcom(upp:ncom); Iupd=Icom(upp:ncom); dIupd=dIcom(upp:ncom); nupd=ncom-upp+1; % data before upper cut-off are discarded 

%largest Q cut-off
if lowsiz(1,u)> 0
   Qlcoff=lowsiz(1,u); % the largest Q cut-off is called
else
    Qlcoff=Qcom(end); % otherwise, the largest Q cut-off is the last Q value
end
for i=1:nupd % lower cut-off finding operation
    if Qupd(i) < Qlcoff && i==nupd
       lower=nupd;
       break
    elseif Qupd(i) == Qlcoff
           lower=i;
           break
    elseif Qupd(i) > Qlcoff
           FQ=[log10(Qupd(i-1)) log10(Qupd(i))]; 
           FI=[log10(Iupd(i-1)) log10(Iupd(i))]; 
           FL=2;
           [a,b,r2]=LSFlin(FQ,FI,FL);
           Ilcoff=10^(a+b*log10(Qlcoff));
           Qupd(i)=Qlcoff; Iupd(i)=Ilcoff;
           lower=i;
           break
    end
end
Qsmooth=Qupd(1:lower); Ismooth=Iupd(1:lower); dIsmooth=dIupd(1:lower); % data after lower cut-off are discarded and data are ready for smoothing

%%curve smoothing: Part 1
nsmt1=0; %degree of smoothing
for i=1:nsmt1 %smooth operation for reducing more noises
Ismooth=smooth(Qsmooth,Ismooth,0.04,'loess');
end
Qfin=Qsmooth; Ifin=Ismooth'; dIfin=dIsmooth'; % data after first round of smoothing
nfin=lower;
Qfin1(u,1:nfin)=Qfin; Ifin1(u,1:nfin)=Ifin; dIfin1(u,1:nfin)=dIfin; 

%%curve smoothing: Part 2
qsmooth1=qisolp;
qsmooth2=qfvolp;
for i=1:nfin
    if Qfin(i) >= qsmooth1
       break 
    end
end
qnsmooth1=i; insmooth1=i; % I-Q value at the begining of overlap area
for i=1:nfin
    if Qfin(i) >= qsmooth2
        break
    end
end
qnsmooth2=i; insmooth2=i; % I-Q value at the end of overlap area

for i=1:nfin
    if Qfin(i) <= Qfin(qnsmooth1) % smoothing operation for the data points between the largest scatterer and the begining of overlap area
        k=1; 
        T=1; % the number of points before and after an individual data point from which the slope of the individual data point is calculated
        TT=2*T+1;
        for t=1:TT
            j=i-1+t-T;
            if j > nfin
                j=nfin;
                k=k-1;
            elseif j <= 1
                    j=1;
                    k=1;
            end
            Qsm(u,k)=Qfin1(u,j);
            Ism(u,k)=Ifin1(u,j);
            k=k+1;
        end
        FQ=Qsm(u,1:k-1);
        FI=Ism(u,1:k-1);
        Fl=length(FQ);
        [A,B,r2]=LSFpow(FQ,FI,Fl);
        Ifin(i)=A*((Qfin(i))^B); % I values of this region are smoothed
    elseif Qfin(i) >= Qfin(qnsmooth2) % smoothing operation for the data points between the end of overlap area and the smallest scatterer 
            k=1;
            T=1; % the number of points before and after an individual data point from which the slope of the individual data point is calculated
            TT=2*T+1;
            for t=1:TT
                j=i-1+t-T;
                if j > nfin
                   j=nfin;
                   k=k-1;
                elseif j <= 1
                       j=1;
                       k=1;
                end
                Qsm(u,k)=Qfin1(u,j);
                Ism(u,k)=Ifin1(u,j);
                k=k+1;
            end
            FQ=Qsm(u,1:k-1);
            FI=Ism(u,1:k-1);
            Fl=length(FQ);
            [A,B,r2]=LSFpow(FQ,FI,Fl);
            Ifin(i)=A*((Qfin(i))^B); % I values of this region are smoothed
    else % smoothing operation for the data points within overlap area
    k=1;
    T=1; % the number of points before and after an individual data point from which the slope of the individual data point is calculated
    TT=2*T+1;
    for t=1:TT
        j=i-1+t-T;
        if j > nfin
            j=nfin;
            k=k-1;
        elseif j <= 1
            j=1;
            k=1;
        end
        Qsm(u,k)=Qfin1(u,j);
        Ism(u,k)=Ifin1(u,j);
        k=k+1;
    end
    FQ=Qsm(u,1:k-1);
    FI=Ism(u,1:k-1);
    Fl=length(FQ);
    [A,B,r2]=LSFpow(FQ,FI,Fl);
    Ifin(i)=A*((Qfin(i))^B); % I values of this region are smoothed
    end
end

%%slope for pore fractals
Qslpm1=0.0003; % upper cut-off for calculating the slope of pore fractals
Qslpm2=0.003; % lower cut-off for calculating the slope of pore fractals
pfdupper(u,1)=Qslpm1; % upper cut-off is reported in output
pfdlower(u,1)=Qslpm2; % lower cut-off is reported in output
for i=1:nfin
    if Qfin(i) >= Qslpm1
       break 
    end
end
qslpm1=i; islpm1=i;
for i=1:nfin
    if Qfin(i) >= Qslpm2
        break
    end
end
qslpm2=i; islpm2=i;
FQ=Qfin(qslpm1:qslpm2); FI=Ifin(islpm1:islpm2); Fl=length(FQ);
[A,B,r2]=LSFpow(FQ,FI,Fl);
Smass=B; % slope of pore fractals
Dporefract=-B; % pore fractal dimension

%%slope for surface fractals
Qslps1=0.003; % upper cut-off for calculating the slope of surface fractals
Qslps2=0.03; % lower cut-off for calculating the slope of surface fractals
sfdupper(u,1)=Qslps1; % upper cut-off is reported in output
sfdlower(u,1)=Qslps2; % lower cut-off is reported in output
for i=1:nfin
    if Qfin(i) >= Qslps1
       break 
    end
end
qslps1=i; islps1=i;
for i=1:nfin
    if Qfin(i) >= Qslps2
        break
    end
end
qslps2=i; islps2=i;
FQ=Qfin(qslps1:qslps2); FI=Ifin(islps1:islps2); Fl=length(FQ);
[A,B,r2]=LSFpow(FQ,FI,Fl);
Ssurf=B; % slope for surface fractals
Dsurffract=B+6; % surface fractal dimension

%%general slope
Qslp1=0.0003; % upper cut-off for calculating the general slope
Qslp2=0.03; % lower cut-off for calculating the general slope
slopupper(u,1)=Qslp1; fdupper(u,1)=Qslp1; % upper cut-off is reported in output
sloplower(u,1)=Qslp2; fdlower(u,1)=Qslp2; % lower cut-off is reported in output
for i=1:nfin
    if Qfin(i) >= Qslp1
       break 
    end
end
qslp1=i; islp1=i;
for i=1:nfin
    if Qfin(i) >= Qslp2
        break
    end
end
qslp2=i; islp2=i;
FQ=Qfin(qslp1:qslp2); FI=Ifin(islp1:islp2); Fl=length(FQ);
[A,B,r2]=LSFpow(FQ,FI,Fl);
Sgenr=B; % general slope
Dfract=B+6; % surface fractal dimension

%%reports
Slope(3,u)=0; Slope(1,u)=Smass; Slope(2,u)=Ssurf; Slope(3,u)=Sgenr; % slopes are reported
FractalDim(3,u)=0; FractalDim(1,u)=Dporefract; FractalDim(2,u)=Dsurffract; FractalDim(3,u)=Dfract; % fractal dimensions are reported
Ib(2,u)=0; Ib(1,u)=Ibckvsas; Ib(2,u)=Ibcksas; % background values are reported
Nfinl(u,1)=nfin; % the number of total data points
Qtr(u,1:Nfinl(u,1))=Qfin(1:Nfinl(u,1)); % manipulatd Q values
Itr(u,1:Nfinl(u,1))=Ifin(1:Nfinl(u,1)); % manipulated I values
dItr(u,1:Nfinl(u,1))=dIfin(1:Nfinl(u,1)); % manipulated dI values
Qgraph=Qtr(u,1:Nfinl(u,1)); Igraph=Itr(u,1:Nfinl(u,1)); % the figure is displayed in command window
figure 
loglog(Qv, Iv, 'r^', 'MarkerSize',8 ,'DisplayName', 'VSAS Raw Data')
hold on
loglog(Qs, Is, 'bv', 'MarkerSize',8 ,'DisplayName', 'SAS Raw Data')
hold on
loglog(Qgraph, Igraph, 'ko', 'MarkerSize',5 ,'MarkerfaceColor','k','DisplayName', 'Manipulated (V)SAS Data')
xlabel('Q, �^-^1')
ylabel('I(Q), cm^-^1')
title(['Manipulated (V)SAS data',SN(u)])
legend('show')
legend('Location','northeast')
legend('boxoff')
hold off
end
fprintf('========================================\n')
fprintf('No\t Sample Name\t IBG_VSAS\t IBG_SAS\n')
fprintf('========================================\n')
for u=1:NSheet % the table is reported in the command window
fdfd=char(SN(u));
fprintf('%d\t ',u)
fprintf([fdfd '\t         '])
fprintf('%4.3f\t  %4.3f\n', Ib(1,u), Ib(2,u))
end
fprintf('========================================\n')
fprintf('\n')
fprintf('Data have been manipulated. Proceed to the "data analysis" module.\n')
fprintf('\n')