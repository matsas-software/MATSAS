This package includes 2 programs including data_manipulation_SAS_only.m and data_manipulation_VSAS_only.m.
data_manipulation_SAS_only.m or data_manipulation_VSAS_only.m have been developed to manipulate SAS data or VSAS data, respectively. The merging process is excluded.
If users have one curve (SAS or VSAS) only, they must replace data_manipulation.m with data_manipulation_SAS_only.m or data_manipulation_VSAS_only.m in the MATSAS program folder.
The analysis of VSAS data is valid for macropore sizes (above ~ 100 nm). The results associated with sizes less than it (~ 100 nm) are not vaild, for example mesoporosity. 
MATSAS Development Team
matsas.software@gmail.com